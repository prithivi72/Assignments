from schemas.models import Student
from scripts.core.db.mongo_db import collection


def get_course(name: str):
    try:
        dept = collection.find_one({"name": name})
        if dept:
            return {"name is available"}
        return {"Error": "name not found"}
    except Exception as e:
        return {"Error": str(e)}


def add_course(sid: Student):
    try:
        result = collection.insert_one(sid.__dict__)
        return {"Message": "course added successfully"}
    except Exception as e:
        return {"Error": str(e)}


def update_course(course_name: str, new_course: Student):
    try:
        response = collection.update_one({"course": course_name}, {"$set": new_course.__dict__})
        if response.modified_count > 0:
            return {"message": "Course updated successfully"}
        return {"Error": "Course not found"}
    except Exception as a:
        return {"Error": str(a)}


def delete_course(course_name: str):
    try:
        response = collection.delete_one({"course":course_name})
        if response.deleted_count > 0:
            return {"Message":"Course deleted successfully"}
        return {"Erroe":"course not found"}
    except Exception as a:
        return{"Error":str(a)}
