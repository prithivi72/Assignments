from fastapi import APIRouter
from schemas.models import Student
from scripts.core.handlers.grocery_handler import get_course, add_course, update_course, delete_course

app_router = APIRouter()


@app_router.get('/get course')
def func(name: str):
    return get_course(name)


@app_router.post('/add course')
def func(sid: Student):
    return add_course(sid)


@app_router.put('/update course')
def func(course_name: str, new_course: Student):
    return update_course(course_name, new_course)


@app_router.delete('/delete course')
def func(course_name: str):
    return delete_course((course_name))